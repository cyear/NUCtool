#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

for cmd in pipewire wpctl sed head mktemp; do
    command -v "$cmd" >/dev/null 2>&1 || {
        printf '缺少命令：%s（请安装 PipeWire/WirePlumber）\n' "$cmd" >&2
        exit 1
    }
done

if [ ! -r "$ROOT/sr_music.so" ]; then
    printf '插件文件缺失：%s/sr_music.so\n' "$ROOT" >&2
    exit 1
fi

sink=$(wpctl inspect @DEFAULT_AUDIO_SINK@ 2>/dev/null |
    sed -n 's/.*node\.name = "\([^"]*\)".*/\1/p' | head -n 1)
if [ -z "$sink" ]; then
    printf '%s\n' '读取不到 PipeWire 默认输出设备。请确认 PipeWire/WirePlumber 正在运行。' >&2
    exit 1
fi
case "$sink" in
    sr_music_sink|AlderCounty*)
        printf '%s\n' '默认输出不能是 AlderCounty Music 本身；请先切回实际扬声器/耳机。' >&2
        exit 1
        ;;
esac

tmp=$(mktemp "${TMPDIR:-/tmp}/aldercounty-music.XXXXXX.conf")
cleanup() { rm -f "$tmp"; }
trap cleanup EXIT HUP INT TERM
sed "s|@TARGET@|$sink|g" "$ROOT/sr-music.conf.in" > "$tmp"
export LADSPA_PATH="$ROOT${LADSPA_PATH:+:$LADSPA_PATH}"

printf '临时输出：AlderCounty Music\n播放端：%s\n' "$sink"
printf '%s\n' '请把正在播放的应用流也切到 AlderCounty Music；Ctrl-C 退出。'
pipewire -c "$tmp"
